# Pro Camera (Android)

A starter Android Studio project for an automatic-enhancement camera.

## What works in this starter
- Opens the Android camera preview using CameraX.
- Captures a JPEG when you tap **TAKE PHOTO**.
- Saves the original and an automatically enhanced copy in `Pictures/Pro Camera`.
- The enhancement is lightweight, on-device image processing (gentle contrast/brightness lift), so it works without an internet connection.

## Important limitation
This first build is **not yet connected to ChatGPT or a generative AI image-editing model**. It does not perform AI object removal, background replacement, or advanced portrait retouching. Those features need an image-editing API and a secure backend. Do not put a private API key directly in the Android app; APKs can be reverse-engineered.

## Build the APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Open the `ProCamera` folder in Android Studio.
4. Allow Gradle sync and install any requested Android SDK 35 components.
5. Connect your Android phone with USB debugging enabled, or use an emulator.
6. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show the APK location. Transfer it to your phone and install it.

## Requirements
- Android Studio with JDK 17.
- Android SDK 35.
- Android 8.0 (API 26) or newer for the app.

## Project structure
- `app/src/main/java/com/poprus/procamera/MainActivity.kt` — camera, capture, and enhancement logic.
- `app/src/main/AndroidManifest.xml` — camera permission and launcher activity.
- `app/build.gradle.kts` — CameraX and Android dependencies.

## Next development step
Add a secure server endpoint that calls an image-editing model after capture, then returns the edited image. Add a user-controlled setting for automatic cloud editing so the user can manage data use and API costs.
