package com.poprus.procamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.pow

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var captureButton: Button
    private var imageCapture: ImageCapture? = null
    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else {
            status.text = "Camera permission is needed to take photos."
            captureButton.isEnabled = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildInterface() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 34)
            setBackgroundColor(0x99000000.toInt())
        }
        val title = TextView(this).apply {
            text = "PRO CAMERA"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.18f
        }
        status = TextView(this).apply {
            text = "Automatic enhancement is ON"
            textSize = 14f
            setTextColor(0xFFE5E7EB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }
        captureButton = Button(this).apply {
            text = "●  TAKE PHOTO"
            textSize = 16f
            isAllCaps = false
            setOnClickListener { takePhoto() }
        }
        panel.addView(title, LinearLayout.LayoutParams(-1, -2))
        panel.addView(status, LinearLayout.LayoutParams(-1, -2))
        panel.addView(captureButton, LinearLayout.LayoutParams(-1, -2))
        val params = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        root.addView(panel, params)
        setContentView(root)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setJpegQuality(95)
                .build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                status.text = "Ready • Auto enhancement ON"
                captureButton.isEnabled = true
            } catch (e: Exception) {
                status.text = "Could not start camera: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        captureButton.isEnabled = false
        status.text = "Taking photo and enhancing…"
        val name = "ProCamera_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Pro Camera")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        capture.takePicture(output, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                val uri = result.savedUri
                if (uri == null) {
                    runOnUiThread { finishCapture("Photo saved, but couldn't reopen it.") }
                    return
                }
                try {
                    val original = contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it)
                    } ?: throw IllegalStateException("Could not read captured photo")
                    val enhanced = enhancePhoto(original)
                    val editedUri = saveEnhanced(enhanced)
                    runOnUiThread {
                        finishCapture(if (editedUri != null) "Enhanced photo saved in Pictures/Pro Camera" else "Photo captured; enhanced copy could not be saved.")
                    }
                } catch (e: Exception) {
                    runOnUiThread { finishCapture("Photo captured. Enhancement failed: ${e.localizedMessage}") }
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { finishCapture("Capture failed: ${exception.message}") }
            }
        })
    }

    // Lightweight offline enhancement: gentle contrast, brightness and color lift.
    // This is image processing, not generative AI or a face-changing filter.
    private fun enhancePhoto(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(source.width * source.height)
        source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
        for (i in pixels.indices) {
            val c = pixels[i]
            fun adjust(channel: Int): Int {
                val normalized = channel / 255.0
                val lifted = ((normalized - 0.5) * 1.08 + 0.5 + 0.015).coerceIn(0.0, 1.0)
                return (lifted * 255.0).toInt().coerceIn(0, 255)
            }
            val r = adjust(Color.red(c))
            val g = adjust(Color.green(c))
            val b = adjust(Color.blue(c))
            pixels[i] = Color.argb(Color.alpha(c), r, g, b)
        }
        output.setPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
        return output
    }

    private fun saveEnhanced(bitmap: Bitmap): Uri? {
        val name = "ProCamera_Enhanced_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Pro Camera")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { stream ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 96, stream)
        } ?: return null
        return uri
    }

    private fun finishCapture(message: String) {
        status.text = message
        captureButton.isEnabled = true
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
